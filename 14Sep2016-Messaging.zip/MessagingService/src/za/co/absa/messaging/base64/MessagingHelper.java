package za.co.absa.messaging.base64;

import java.util.ArrayList;
import java.util.List;

import za.co.absa.messaging.EmailMessageSender;
import za.co.absa.messaging.Mime;

public class MessagingHelper {
	private EmailMessageSender messageSender;

	public MessagingHelper() {
		try {
			messageSender = new EmailMessageSender();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void sendMessage(String pFrom, String pTo, String pCc, String pBcc, String pSubject, String pMessageType, String pBody, String pAttach1, String pAttach1FN, String pAttach1MIME, String pAttach2, String pAttach2FN, String pAttach2MIME, String pAttach3, String pAttach3FN, String pAttach3MIME, String pAttach4, String pAttach4FN, String pAttach4MIME, String pAttach5, String pAttach5FN, String pAttach5MIME, String pOriginalBody) throws Exception {
		MessageWrapper vMessageWrapper = new MessageWrapper();
		List<String> vTo = new ArrayList<String>();
		vTo.add(pTo);
		vMessageWrapper.setTo(vTo);
		
		if(pCc != null && !pCc.isEmpty()) {
			List<String> vCc = new ArrayList<String>();
			vTo.add(pCc);
			vMessageWrapper.setCc(vCc);
		}
		if(pBcc != null && !pBcc.isEmpty()) {
			List<String> vBCc = new ArrayList<String>();
			vBCc.add(pBcc);
			vMessageWrapper.setBcc(vBCc);
		}
		vMessageWrapper.setFrom(pFrom);
		vMessageWrapper.setOriginalBody(pOriginalBody);
		vMessageWrapper.setBody(pBody);
		vMessageWrapper.setSubject(pSubject);
		
		if(pAttach1 != null && pAttach1 != "") {
			vMessageWrapper.attach(pAttach1, Mime.PDF.getMime(), pAttach1FN);
		}
		if(pAttach2 != null && pAttach2 != "") {
			vMessageWrapper.attach(pAttach2, Mime.PDF.getMime(), pAttach2FN);
		}
		if(pAttach3 != null && pAttach3 != "") {
			vMessageWrapper.attach(pAttach3, Mime.PDF.getMime(), pAttach3FN);
		}
		
		if(pAttach4 != null && pAttach4 != "") {
			vMessageWrapper.attach(pAttach4, Mime.PDF.getMime(), pAttach4FN);
		}
		
		if(pAttach5 != null && pAttach5 != "") {
			vMessageWrapper.attach(pAttach5, Mime.PDF.getMime(), pAttach5FN);	
		}
		
		vMessageWrapper.setMime(Mime.HTML.getMime());
		messageSender.sendMessage(vMessageWrapper.toMessage());
	}
	
	
	public void sendMessage(MessageWrapper messageWrapper) throws Exception {
		messageSender.sendMessage(messageWrapper.toMessage());
	}

}
