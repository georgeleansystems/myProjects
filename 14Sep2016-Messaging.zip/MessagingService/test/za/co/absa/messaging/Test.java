package za.co.absa.messaging;

public class Test {

	public static void main(String[] args) {
		MessagingHelperTest messagingHelperTest = new MessagingHelperTest();
		try {
			messagingHelperTest.testSendMessage();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void sendTest(String args) {
		MessagingHelperTest messagingHelperTest = new MessagingHelperTest();
		try {
			messagingHelperTest.testSendMessage();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
