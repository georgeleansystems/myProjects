package za.co.absa.messaging;

import java.io.FileInputStream;

import javax.mail.Session;

import org.junit.Test;

import com.lowagie.text.pdf.codec.Base64;

import za.co.absa.messaging.EmailMessageSender;
import za.co.absa.messaging.MailSessionFactory;
import za.co.absa.messaging.Message;


public class MessageTest {
	
	@Test
	public void testGetInstance() throws Exception{
		
		//TODO: Create a mail handler class.
		FileInputStream fis1 = new FileInputStream("C:/Users/ABTMAZU/Downloads/MessagingServiceBase64/MessagingService/FICAREQUESTEMAIL.pdf");		
		byte[] bytes1 = new byte[fis1.available()];		
		fis1.read(bytes1);

		Message message = new Message();
		String mailTrail = Base64.decodeToObject("RnJvbToJTWFkb25zZWxhLCBUZXJlbmNlOiBBYnNhDQpTZW50OgkzMSBBdWd1c3QgMjAxNiAwNDo1NiBQTQ0KVG86CWRldi1uZGUtc3lzdGVtDQpTdWJqZWN0OglGVzogMDAwMDAwMDAwMDAwMA0KQXR0YWNobWVudHM6CXNjYW4wMzg0LnBkZg0KDQoNCg0KRnJvbTogTWFkb25zZWxhLCBUZXJlbmNlOiBBYnNhICANClNlbnQ6IDMxIEF1Z3VzdCAyMDE2IDAyOjAxIFBNIA0KVG86IHVhdC1uZGUtc3lzdGVtIA0KU3ViamVjdDogMDAwMDAwMDAwMDAwMA0KDQoNCg0KRnJvbTogTWFkb25zZWxhLCBUZXJlbmNlOiBBYnNhICANClNlbnQ6IDMwIEF1Z3VzdCAyMDE2IDA5OjM0IEFNIA0KVG86IGRldi1uZGUtc3lzdGVtIA0KU3ViamVjdDogMTkwMTA1NTU1MTA4OQ0KDQoNCg0KRnJvbTogTWFkb25zZWxhLCBUZXJlbmNlOiBBYnNhICANClNlbnQ6IDI5IEF1Z3VzdCAyMDE2IDExOjQ1IFBNIA0KVG86IGRldi1uZGUtc3lzdGVtIA0KU3ViamVjdDogMjAwMTA1NTU1MTA4OQ0KDQoNCg0KRnJvbTogTWFkb25zZWxhLCBUZXJlbmNlOiBBYnNhICANClNlbnQ6IDI1IEF1Z3VzdCAyMDE2IDA4OjQ1IFBNIA0KVG86IGRldi1uZGUtc3lzdGVtIA0KU3ViamVjdDogMjcxMTA4NTAzMzA4NA0KDQoNCg==").toString();
		message
		.to("terence.madonsela@absa.co.za")
		.from("bpmdev@absa.co.za")
		.subject("Hello - From NDE Mailer")
		.body(mailTrail)
		.attach(bytes1, "application/pdf", "page_1_to_2.pdf");

		message.setMime(Mime.HTML.getMime());
		
		MailSessionFactory instance = MailSessionFactory.getInstance();
		org.junit.Assert.assertNotNull(instance);
		
		Session session = instance.getSession();

		org.junit.Assert.assertNotNull(session);
		
		EmailMessageSender messageSender = new EmailMessageSender(session);
		
		messageSender.sendMessage(message);
		fis1.close();

	}

}
