
import java.io.InputStream;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.URLName;

import com.sun.mail.pop3.POP3SSLStore;

public class MainClass{

   public static void check() 
   {
      try {

      //create properties field
      final Properties properties = new Properties();

      final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

      properties.setProperty( "mail.pop3.socketFactory.class", SSL_FACTORY);
      InputStream is = MainClass.class.getClassLoader().getResourceAsStream("pop3.properties");
      properties.load(is);
      
      Session emailSession = Session.getDefaultInstance(properties );
      Store store = emailSession.getStore("pop3");
      String user = properties.getProperty("mail.pop3.username");
      
      String password = properties.getProperty("mail.pop3.password");
      
      URLName url = new URLName("pop3", "mobile.absa.co.za", 995, "",
              user, password);
       
      store = new POP3SSLStore(emailSession, url);
      store.connect();
      
      //create the folder object and open it
      Folder emailFolder = store.getFolder("INBOX");
      emailFolder.open(Folder.READ_ONLY);

      // retrieve the messages from the folder in an array and print it
      Message[] messages = emailFolder.getMessages();
      System.out.println("Number of mesaages - " + messages.length);

      for (int i = 0, n = messages.length; i < n; i++) {
         Message message = messages[i];
         System.out.println("---------------------------------------------------");
         System.out.println("Email Number " + (i + 1));
         System.out.println("From: " + message.getFrom()[0]);
         System.out.println("Subject: " + message.getSubject());
         //System.out.println("Text: " + message.getContent().toString());

      }

      //close the store and folder objects
      emailFolder.close(false);
      store.close();

      } catch (NoSuchProviderException e) {
         e.printStackTrace();
      } catch (MessagingException e) {
         e.printStackTrace();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   public static void main(String[] args) {
     check();
   }

}