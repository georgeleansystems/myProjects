package za.co.absa.document.converters;

public interface TestConst {
	public static final String FILE_LOCATION = "/Users/sellotseka/Documents/lean_code/PDFSplitter/test/";
}
