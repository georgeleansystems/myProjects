package za.co.absa.document.converters;

import org.junit.Test;

import za.co.absa.document.splitter.DocumentSplitterFactory;


public class DocumentConverterFactoryTest {
	
	@Test
	public void testGetInstance(){
		
		DocumentConverterFactory instance = DocumentConverterFactory.getInstance();
		org.junit.Assert.assertNotNull(instance);
	}

}
