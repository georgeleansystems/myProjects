package za.co.absa.document.converters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.junit.Test;

import za.co.absa.document.Mime;

public class HTMLDocumentConverterTest {
	
	
	@Test
	public void testExtractPages() throws Exception{
		
		InputStream fis = new FileInputStream("NDEEXEnglishABSATRUSTWILLS.doc.html");
		
		byte[] bytes = new byte[fis.available()];
		
		fis.read(bytes);
		
		byte[] subDocument = DocumentConverterFactory.getInstance().getConverter(Mime.HTML,Mime.PDF).convert(bytes, Mime.HTML.getMime(),Mime.PDF.getMime());
		
		File file = new File(System.currentTimeMillis()+".html.converted.pdf");
		
		file.createNewFile();
		
		FileOutputStream fos = new FileOutputStream(file);
		fos.write(subDocument);
		
		fos.flush();
		fos.close();
		fis.close();
	
	}
}
 