package za.co.absa.document.converters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.junit.Test;

import za.co.absa.document.Mime;

public class JPEGDocumentConverterTest {
	
	
	@Test
	public void testExtractPages() throws Exception{
		InputStream fis = getClass().getResourceAsStream("to_convert.jpg");
		
		byte[] bytes = new byte[fis.available()];
		
		fis.read(bytes);
		
		byte[] subDocument = DocumentConverterFactory.getInstance().getConverter(Mime.JPG,Mime.PDF).convert(bytes, "image/jpg","application/pdf");
		
		File file = new File(System.currentTimeMillis()+".jpg.converted.pdf");
		
		file.createNewFile();
		
		FileOutputStream fos = new FileOutputStream(file);
		fos.write(subDocument);
		
		fos.flush();
		fos.close();
		fis.close();
	
	}
}
 