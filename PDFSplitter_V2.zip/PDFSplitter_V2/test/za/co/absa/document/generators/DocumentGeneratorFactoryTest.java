package za.co.absa.document.generators;

import org.junit.Test;

import za.co.absa.document.converters.DocumentConverterFactory;


public class DocumentGeneratorFactoryTest {
	
	@Test
	public void testGetInstance(){
		
		DocumentGeneratorFactory instance = DocumentGeneratorFactory.getInstance();
		org.junit.Assert.assertNotNull(instance);
	}

}
