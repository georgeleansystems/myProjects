package za.co.absa.document.generators;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.junit.Test;

import za.co.absa.document.converters.DocumentConverterFactory;
import za.co.absa.document.converters.TestConst;

public class DocumentGeneratorTest {
	
	
	@Test
	public void testExtractPages() throws Exception{
		FileInputStream fis = new FileInputStream("NDEEXEnglishBONDLETTER.html");
		
		byte[] bytes = new byte[fis.available()];
		
		fis.read(bytes);
		
		byte[] subDocument = DocumentGeneratorFactory.getInstance().getGenerator("application/pdf").
				generate(bytes, "application/pdf",
						new String[][]{
					{"{$DATE}","12/12/2016"},
					{"{$EXECUTOR}","Mr XYZ Executors"},
					{"{$EMAIL}","mrxyz@gmail.com"},
					{"{$ESTATELATE}","MR Late Estate"},
					{"{$REQUESTTITLEDEEDCOPY_Y_N}","Y"},
					{"{$IDENTITYNUMBER}","12345678910"}
					});
		
		File file = new File(System.currentTimeMillis()+".html.generated.pdf");
		
		file.createNewFile();
		
		FileOutputStream fos = new FileOutputStream(file);
		fos.write(subDocument);
		
		fos.flush();
		fos.close();
		fis.close();
	
	}
}
 