package za.co.absa.document.splitter;

import org.junit.Test;

import za.co.absa.document.splitter.DocumentSplitterFactory;


public class DocumentSplitterFactoryTest {
	
	@Test
	public void testGetInstance(){
		
		DocumentSplitterFactory instance = DocumentSplitterFactory.getInstance();
		org.junit.Assert.assertNotNull(instance);
	}

}
