package za.co.absa.document.splitter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.sun.xml.internal.messaging.saaj.util.ByteInputStream;


public class PDFSplitterTest {
	
	byte [] array = null; //byte array of the main document
	@Test
	public void testExtractPages() throws IOException, Exception{
	//	DocumentSplitterTest splitter = DocumentSplitterFactory.getInstance().getSplitter("application/pdf");//TODO: Confirm mime type
//		Assert.assertNotNull(splitter);
//		
//		byte [] fullDocument = getBytes(); //assign full Document to the value of the array of bytes
//		
//		byte [] subDocument = splitter.extractPages(fullDocument, new int[]{1,2,4});
//		
		//TODO Create Itext isntance from sub-document
		//Count number of pages in sub-document
		//Assert that sub-document pages are 3
		
		
		//int [] pages;
		//org.junit.Assert.assertEquals(outputPDF.getNumberOfPages, pages.length());
	}
	
	/*public static void main(String[] args) {
         try {
                for(int i=0;i < array.length();i++){
             * 	document.newPage();
             *  page = writer.getImportedPage(inputPDF, array[i]);
                cb.addTemplate(page, 0, 0);
                i++;
             * 
             * } 
                Test.splitPDF(new FileInputStream("/home/george/Desktop/File.pdf"),
                        new FileOutputStream("/home/george/Desktop/Output1.pdf"), 1, 15);

                Test.splitPDF(new FileInputStream("/home/george/Desktop/File.pdf"),
                        new FileOutputStream("/home/george/Desktop/Output2.pdf"), 16, 30);

             } catch (Exception e) {
                System.err.println(e.getMessage());
             }
        }
*/
	
	@Test
	public byte[] getBytes() throws IOException, Exception{
		Assert.assertNotNull(array);
		return array;
	}
	
	public static void splitPDF(ByteInputStream inputStream,
            ByteArrayOutputStream outputStream, int fromPage, int toPage)throws IOException, Exception {

    Document document = new Document();

    try {
            PdfReader inputPDF = new PdfReader(inputStream);
            int totalPages = inputPDF.getNumberOfPages();

            // Make fromPage equals to toPage if it is greater
            if (fromPage > toPage) {
                    fromPage = toPage;/*	the if statement needs to be removed
                     						validation of the page required will be performed just before page creation is actioned*/
            }
            if (toPage > totalPages) {
                    toPage = totalPages;
            }
            // Create a writer for the outputstream
            PdfWriter writer = PdfWriter.getInstance(document, outputStream);
            document.open();
            // Holds the PDF data
            PdfContentByte cb = writer.getDirectContent();
            PdfImportedPage page;

            while (fromPage <= toPage) {
                    document.newPage();
                    page = writer.getImportedPage(inputPDF, fromPage);
                    cb.addTemplate(page, 0, 0);
                    fromPage++;
            }
            /*	replace the while statement with this for loop 
             * check if the pages number is not greater that the total number of pages 
             * print the last page if the page number is greater than the total number of pages
               for(int i=0;i < array.length();i++){
               	document.newPage();
               if(array[i] > totalPages){
	            	array[i] = totalPages;
	            	page = writer.getImportedPage(inputPDF, array[i]);
	                cb.addTemplate(page, 0, 0);
	                i++;
            	}else{

	                page = writer.getImportedPage(inputPDF, array[i]);
	                cb.addTemplate(page, 0, 0);
	                i++;
               	 }
               } 
               
             */
            outputStream.flush();
            document.close();
            outputStream.close();
    } catch (Exception e) {
            System.err.println(e.getMessage());
    } finally {
            if (document.isOpen())
                    document.close();
            try {
                    if (outputStream != null)
                            outputStream.close();
            } catch (IOException ioe) {
                    System.err.println(ioe.getMessage());
            }
    }
}
	
	/*@Test
	public byte[] file2Byte(byte [] file){
		
		ByteArrayOutputStream bos = null;
		InputStream fis = null;
		File f = null;
		
		try{
			//f = new File(file);
			fis =  new FileInputStream(file);
			bos = new ByteArrayOutputStream();
			byte [] b = new byte[4096];
			int read = 0;
			
			while((read = fis.read(b)) != -1){
				bos.write(b, 0, read);
			}
			
		}catch(IOException ex){
			ex.printStackTrace();
		}finally{
			if(fis != null){
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(bos != null){
				try {
					bos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		}
		
		return bos.toByteArray();
	}
	
	*/
	
}
