package za.co.absa.document.splitter;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.junit.Test;

import za.co.absa.document.splitter.DocumentSplitterFactory;

public class DocumentSplitterTest {
	
	public static String PROJECT_LOCATION = "";
	
	@Test
	public void testExtractPages() throws Exception{
		//InputStream fis =  getClass().getResourceAsStream("test.pdf");
		FileInputStream fis = new FileInputStream("test.pdf");
		
		byte[] bytes = new byte[fis.available()];
		
		fis.read(bytes);
		
		DocumentSplitterFactory instance = DocumentSplitterFactory.getInstance();
		DocumentSplitter splitter = instance.getSplitter("application/pdf");
		
		byte[] subDocument = splitter.extractPages(bytes, new int[]{4,5});
		
		File file = new File(System.currentTimeMillis()+"subdoc.pdf");
		
		file.createNewFile();
		
		FileOutputStream fos = new FileOutputStream(file);
		fos.write(subDocument);
		
		fos.flush();
		fos.close();
		fis.close();
	
	}
}
 