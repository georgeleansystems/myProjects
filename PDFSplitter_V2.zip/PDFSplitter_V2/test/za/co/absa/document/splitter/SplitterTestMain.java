package za.co.absa.document.splitter;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;

public class SplitterTestMain {
        // Split PDF files in Java using iText JAR

        public static void main(String[] args) {
         try {
                SplitterTestMain.splitPDF(new FileInputStream("/home/george/Desktop/File.pdf"),
                        new FileOutputStream("/home/george/Desktop/Output1.pdf"), 1, 15);

                SplitterTestMain.splitPDF(new FileInputStream("/home/george/Desktop/File.pdf"),
                        new FileOutputStream("/home/george/Desktop/Output2.pdf"), 16, 30);

             } catch (Exception e) {
                System.err.println(e.getMessage());
             }
        }

        public static void splitPDF(FileInputStream inputStream,
                        FileOutputStream outputStream, int fromPage, int toPage) {

                Document document = new Document();

                try {
                        PdfReader inputPDF = new PdfReader(inputStream);
                        int totalPages = inputPDF.getNumberOfPages();

                        // Make fromPage equals to toPage if it is greater
                        if (fromPage > toPage) {
                                fromPage = toPage;
                        }
                        if (toPage > totalPages) {
                                toPage = totalPages;
                        }

                        // Create a writer for the outputstream
                        PdfWriter writer = PdfWriter.getInstance(document, outputStream);
                        document.open();
                        // Holds the PDF data
                        PdfContentByte cb = writer.getDirectContent();
                        PdfImportedPage page;

                        while (fromPage <= toPage) {
                                document.newPage();
                                page = writer.getImportedPage(inputPDF, fromPage);
                                cb.addTemplate(page, 0, 0);
                                fromPage++;
                        }
                        outputStream.flush();
                        document.close();
                        outputStream.close();
                } catch (Exception e) {
                        System.err.println(e.getMessage());
                } finally {
                        if (document.isOpen())
                                document.close();
                        try {
                                if (outputStream != null)
                                        outputStream.close();
                        } catch (IOException ioe) {
                                System.err.println(ioe.getMessage());
                        }
                }
        }
}