package za.co.absa.document.merger;

import org.junit.Test;


public class DocumentMergerFactoryTest {
	
	@Test
	public void testGetInstance(){
		
		DocumentMergerFactory instance = DocumentMergerFactory.getInstance();
		org.junit.Assert.assertNotNull(instance);
	}

}
