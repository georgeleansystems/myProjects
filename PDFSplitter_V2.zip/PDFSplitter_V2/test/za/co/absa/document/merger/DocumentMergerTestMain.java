package za.co.absa.document.merger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class DocumentMergerTestMain {
	
	
	public static void main(String [] args) throws Exception{
		//InputStream fis =  getClass().getResourceAsStream("test.pdf");
		
		FileInputStream fis1 = new FileInputStream("page_1_to_2.pdf");		
		byte[] bytes1 = new byte[fis1.available()];		
		fis1.read(bytes1);
		
		FileInputStream fis2 = new FileInputStream("page_4_to_5.pdf");		
		byte[] bytes2 = new byte[fis2.available()];		
		fis2.read(bytes2);
		
		byte [][] docs = new byte[][]{bytes2,bytes1};
		
		byte[] subDocument = DocumentMergerFactory.getInstance().getMerger("application/pdf").mergeDocuments(docs, "application/pdf");
		
		File file = new File(System.currentTimeMillis()+"merged.pdf");
		
		file.createNewFile();
		
		FileOutputStream fos = new FileOutputStream(file);
		fos.write(subDocument);
		
		fos.flush();
		fos.close();
		fis1.close();
		fis2.close();
	
	}
}
 