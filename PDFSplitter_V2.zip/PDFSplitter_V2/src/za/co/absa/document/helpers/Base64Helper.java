package za.co.absa.document.helpers;

import com.itextpdf.text.pdf.codec.Base64;

import za.co.absa.document.generators.DocumentGeneratorFactory;
import za.co.absa.document.merger.DocumentMergerFactory;
import za.co.absa.document.splitter.DocumentSplitterFactory;

public class Base64Helper {
	
	public static String extractPages(String fullDocumentBase64, int[] pages)throws Exception{
		return Base64.encodeBytes(DocumentSplitterFactory.getInstance().getSplitter("application/pdf").extractPages(Base64.decode(fullDocumentBase64), pages));
	}
	
	public static String merge(String[] documentsBase64)throws Exception{
		
		byte [][] docs = new byte[documentsBase64.length][];
		
		for(int i = 0;i<documentsBase64.length;i++){
			docs[i]=Base64.decode(documentsBase64[i]);
		}
		
		return Base64.encodeBytes(DocumentMergerFactory.getInstance().getMerger("application/pdf").mergeDocuments(docs, "application/pdf"));
	}
	

	public String generate(String base64Temaplte,String[][] parameters)throws Exception{
		return Base64.encodeBytes(DocumentGeneratorFactory.getInstance().getGenerator("application/pdf").generate(Base64.decode(base64Temaplte), "application/pdf", parameters));
	}

}
