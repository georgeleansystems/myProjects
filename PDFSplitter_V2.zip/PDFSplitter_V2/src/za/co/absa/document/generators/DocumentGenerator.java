package za.co.absa.document.generators;

public interface DocumentGenerator {
	public byte[] generate(byte[] template,String outputMime,String[][] properties) throws Exception;
}
