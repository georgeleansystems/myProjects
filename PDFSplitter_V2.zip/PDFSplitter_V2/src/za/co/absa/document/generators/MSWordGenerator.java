package za.co.absa.document.generators;

import org.jsoup.Jsoup;

public class MSWordGenerator implements DocumentGenerator{

	@Override
	public byte[] generate(byte[] template, String outputMime, String[][] properties) throws Exception {
		
		//--cleanup html			
		final org.jsoup.nodes.Document jsoupdocument = Jsoup.parse(new String(template));
		jsoupdocument.outputSettings().syntax(
				org.jsoup.nodes.Document.OutputSettings.Syntax.xml);

		String templateString = jsoupdocument.html();

		for (String[] entry : properties) {
			templateString = templateString.replace(entry[0], entry[1]);
		}
			
		return templateString.getBytes();
	}

}
