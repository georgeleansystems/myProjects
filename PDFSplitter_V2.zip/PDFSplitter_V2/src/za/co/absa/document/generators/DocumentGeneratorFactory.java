package za.co.absa.document.generators;
import java.util.HashMap;
import java.util.Map;


public class DocumentGeneratorFactory {

	private DocumentGeneratorFactory(){
		generators.put("application/pdf",new PDFGenerator());
	}
	
	private static DocumentGeneratorFactory instance = new DocumentGeneratorFactory();
	
	private Map<String,DocumentGenerator> generators = new HashMap<String,DocumentGenerator>();
	
	public static DocumentGeneratorFactory getInstance(){
		return instance;
	}
	
	public DocumentGenerator getGenerator(String mime){
		return generators.get(mime);
	}
}
