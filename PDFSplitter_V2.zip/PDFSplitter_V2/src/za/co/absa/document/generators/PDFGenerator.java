package za.co.absa.document.generators;

import za.co.absa.document.converters.HTMLToPdfConverter;

public class PDFGenerator implements DocumentGenerator{
	
	MSWordGenerator msWordGenerator = new MSWordGenerator();
	HTMLToPdfConverter wordToPdfConverter = new HTMLToPdfConverter();
	
	public byte[] generate(byte[] template,String outputMime,String[][] properties) throws Exception{			
			byte [] generatedWordDocument = msWordGenerator.generate(template, "application/pdf", properties);
			byte [] generatedPdfDocument = wordToPdfConverter.convert(generatedWordDocument, "","");
			return generatedPdfDocument;
	}
	
}
