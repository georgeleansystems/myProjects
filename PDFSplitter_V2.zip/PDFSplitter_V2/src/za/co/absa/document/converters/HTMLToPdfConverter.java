package za.co.absa.document.converters;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import org.jsoup.Jsoup;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;

public class HTMLToPdfConverter implements DocumentConverter{

	@Override
	public byte[] convert(byte[] fullDocument, String mimeFrom, String mimeTo) throws Exception {
		InputStream is = null;
		ByteArrayOutputStream out = null;
		Document document = null;
		
		try{

			//--cleanup html			
			final org.jsoup.nodes.Document jsoupdocument = Jsoup.parse(new String(fullDocument));
			jsoupdocument.outputSettings().syntax(
					org.jsoup.nodes.Document.OutputSettings.Syntax.xml);

			is = new ByteArrayInputStream(jsoupdocument.html().getBytes());
			out = new ByteArrayOutputStream();
			
			document = new Document(PageSize._11X17);
			PdfWriter writer = PdfWriter.getInstance(document, out);
			writer.setStrictImageSequence(true);
			document.open();
			XMLWorkerHelper.getInstance().parseXHtml(writer, document, is);
			document.close();			
			out.flush();
			return out.toByteArray();
		}
		finally{
            if(out != null)out.flush();
            if(document != null)document.close();
            if(out != null)out.close();
		}
	}
	
}
