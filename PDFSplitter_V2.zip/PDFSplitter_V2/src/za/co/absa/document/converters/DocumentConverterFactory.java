package za.co.absa.document.converters;
import java.util.HashMap;
import java.util.Map;

import za.co.absa.document.Mime;


public class DocumentConverterFactory {

	private DocumentConverterFactory(){
		converters.put(Mime.JPG.getMime()+Mime.PDF.getMime(),new JPEG2PDFCpnverter());
		converters.put(Mime.HTML.getMime()+Mime.PDF.getMime(),new HTMLToPdfConverter());
	}
	
	private static DocumentConverterFactory instance = new DocumentConverterFactory();
	
	private Map<String,DocumentConverter> converters = new HashMap<String,DocumentConverter>();
	
	public static DocumentConverterFactory getInstance(){
		return instance;
	}
	
	public DocumentConverter getConverter(Mime fromMime,Mime toMime){
		return getConverter(fromMime.getMime(),toMime.getMime());
	}
	public DocumentConverter getConverter(String fromMime,String toMime){
		return converters.get(fromMime+toMime);
	}
}
