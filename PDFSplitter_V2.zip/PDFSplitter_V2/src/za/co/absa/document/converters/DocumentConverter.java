package za.co.absa.document.converters;

public interface DocumentConverter {
	public byte[] convert(byte[] fullDocument, String mimeFrom, String mimeTo)throws Exception;
}
