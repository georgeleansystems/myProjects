package za.co.absa.document.converters;

import java.io.ByteArrayOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;

public class JPEG2PDFCpnverter implements DocumentConverter{
	@Override
	public byte[] convert(byte[] fullDocument, String fromMime,String toMime) throws Exception{
		ByteArrayOutputStream os = null;
		Document doc = null;
		
		
		try{		
			os = new ByteArrayOutputStream();
			doc = new Document();
			
	
	        PdfWriter writer = PdfWriter.getInstance(doc, os);
	        doc.open();
	
            doc.newPage();
            doc.add(Image.getInstance(fullDocument));
	        
		}
		finally{
            if(os != null)os.flush();
            //if(doc != null)doc.close();
            if(os != null)os.close();
		}

		return os.toByteArray();
	}
}
