package za.co.absa.document.splitter;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFSplitter implements DocumentSplitter{
	@Override
	public byte[] extractPages(byte[] fullDocument, int[] pages) throws Exception{
		ByteArrayInputStream is = null;
		ByteArrayOutputStream os = null;
		Document doc = null;
		
		
		try{
		
			is = new ByteArrayInputStream(fullDocument);
			os = new ByteArrayOutputStream();
			doc = new Document();
			
	        PdfReader inputPDF = new PdfReader(is);
	
	        PdfWriter writer = PdfWriter.getInstance(doc, os);
	        doc.open();
	        
	        PdfContentByte cb = writer.getDirectContent();
	
	        for(int i = 0 ;i < pages.length; i++){
	                doc.newPage();
	                PdfImportedPage page = writer.getImportedPage(inputPDF, pages[i]);
	                cb.addTemplate(page, 0, 0);
	        }
		}
		finally{
            if(os != null)os.flush();
            if(doc != null)doc.close();
            if(os != null)os.close();
		}

		return os.toByteArray();
	}
}
