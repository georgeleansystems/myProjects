package za.co.absa.document.splitter;
import java.util.HashMap;
import java.util.Map;


public class DocumentSplitterFactory {

	private DocumentSplitterFactory(){
		splitters.put("application/pdf",new PDFSplitter());
	}
	
	private static DocumentSplitterFactory instance = new DocumentSplitterFactory();
	
	private Map<String,DocumentSplitter> splitters = new HashMap<String,DocumentSplitter>();
	
	public static DocumentSplitterFactory getInstance(){
		return instance;
	}
	
	public DocumentSplitter getSplitter(String mime){
		return splitters.get(mime);
	}
}
