package za.co.absa.document.splitter;

public interface DocumentSplitter {
	public byte[] extractPages(byte[] fullDocument, int[] pages)throws Exception;
}
