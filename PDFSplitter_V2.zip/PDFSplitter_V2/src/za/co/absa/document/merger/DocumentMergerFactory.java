package za.co.absa.document.merger;
import java.util.HashMap;
import java.util.Map;


public class DocumentMergerFactory {

	private DocumentMergerFactory(){
		mergers.put("application/pdf",new PDFMerger());
	}
	
	private static DocumentMergerFactory instance = new DocumentMergerFactory();
	
	private Map<String,DocumentMerger> mergers = new HashMap<String,DocumentMerger>();
	
	public static DocumentMergerFactory getInstance(){
		return instance;
	}
	
	public DocumentMerger getMerger(String mime){
		return mergers.get(mime);
	}
}
