package za.co.absa.document.merger;

public interface DocumentMerger {
	public byte[] mergeDocuments(byte[][] documents, String outputMimes) throws Exception;
}
