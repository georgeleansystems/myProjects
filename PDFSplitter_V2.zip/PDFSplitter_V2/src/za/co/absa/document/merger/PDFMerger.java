package za.co.absa.document.merger;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFMerger implements DocumentMerger{
	@Override
	public byte[] mergeDocuments(byte[][] documents, String mime) throws Exception{
		ByteArrayInputStream is = null;
		ByteArrayOutputStream os = null;
		Document doc = null;
		
		
		try{
			os = new ByteArrayOutputStream();
			doc = new Document();
			PdfWriter writer = PdfWriter.getInstance(doc, os);
			doc.open();
	        PdfContentByte cb = writer.getDirectContent();
		
			for(int j = 0;j<documents.length;j++){
				is = new ByteArrayInputStream(documents[j]);
		
		        PdfReader inputPDF = new PdfReader(is);
		
		        
		
		        int pageCount = inputPDF.getNumberOfPages();
		        
		        for(int i = 0 ;i < pageCount; i++){
		                doc.newPage();
		                PdfImportedPage page = writer.getImportedPage(inputPDF, i+1);
		                cb.addTemplate(page, 0, 0);
		        }
			}
		}
		finally{
            if(os != null)os.flush();
            if(doc != null)doc.close();
            if(os != null)os.close();
		}

		return os.toByteArray();
	}
}
