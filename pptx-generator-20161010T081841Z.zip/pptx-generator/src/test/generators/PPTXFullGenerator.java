package test.generators;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import za.co.absa.document.Mime;
import za.co.absa.document.generators.DocumentGenerator;
import za.co.absa.document.generators.DocumentGeneratorFactory;


public class PPTXFullGenerator {
	
	public static void main(String[] args) {

		try {
			
			String template = "ARGO_COMPLIANCE_REPORT_TEMPLATE_XSLT_v.1.3.0.pptx"; 
			
			FileInputStream fis = new FileInputStream(template);
			
			byte[] bytes = new byte[fis.available()];
			
			fis.read(bytes);
			
			DocumentGenerator generator = DocumentGeneratorFactory.getInstance().getGenerator(Mime.PPTX.getMime());

			File fXmlFile = new File("argo_parameters.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			
			//optional, but recommended
			//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();
						
			NodeList nList = doc.getElementsByTagName("param");
			
			Map<String,String> paramsMap = new HashMap<String,String>();
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Element nNode = (Element)nList.item(temp);
				String name = nNode.getElementsByTagName("name").item(0).getTextContent();
				String value = nNode.getElementsByTagName("value").item(0).getTextContent();

				paramsMap.put(name, value);
				
			}

			String [][] params = new String[paramsMap.size()][2];
			
			Iterator<String> keyIter = paramsMap.keySet().iterator();
			
			int i = 0;
			while(keyIter.hasNext()){
				String key = keyIter.next();
				String value = paramsMap.get(key);
				
				params[i][0]=key;
				params[i++][1]=value;
			}
			
			
			byte[] subDocument = generator.
					generate(bytes, Mime.PPTX.getMime(),
							params);
			
			File file = new File("tmp/"+System.currentTimeMillis()+".ARGO_REPORT.generated.pptx");
			
			file.createNewFile();
			
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(subDocument);
			
			fos.flush();
			fos.close();
			fis.close();
						
			System.out.println("XSTL Created Successfully!");

//		} catch (TransformerConfigurationException e) {
//			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}
