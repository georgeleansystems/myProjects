package test.generators;
import java.io.File;
import java.io.FileOutputStream;

import za.co.absa.document.generators.ZipFileBuilder;


public class PPTXTemplateMaker {
	
	public static void main(String[] args) {

		try {
			
			String template = "ARGO_COMPLIANCE_REPORT_TEMPLATE_v.1.3.0.pptx"; 

			String toPath = "tmp/"+System.currentTimeMillis()+".ARGO_COMPLIANCE_REPORT_TEMPLATE_XSLT_v.1.3.0.pptx";
			
			byte[] templateBytes = ZipFileBuilder.getBytes(template);
			
			for(int i = 1;i<11;i++){
				templateBytes = ZipFileBuilder.add(templateBytes, ZipFileBuilder.getBytes("xslt_slide"+i+"/slide1.xslt"), "ppt/slides/slide"+i+".xslt");
			}
			
			File file = new File(toPath);
			
			file.createNewFile();
			
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(templateBytes);
			
			fos.flush();

			
			System.out.println("XSTL Created Successfully!");

//		} catch (TransformerConfigurationException e) {
//			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}
