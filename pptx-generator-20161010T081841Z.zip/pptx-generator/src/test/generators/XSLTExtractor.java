package test.generators;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.transform.TransformerConfigurationException;

import za.co.absa.document.generators.ZipFileBuilder;


public class XSLTExtractor {
	
	public static void main(String[] args) {

		try {
			
			String FOLDER_NUMBER = "4";//Change this number to work with a different folder
			
			String WORKING_DIR = "xslt_slide"+FOLDER_NUMBER+"/";	

			byte [] newZip = ZipFileBuilder.getFile(get(WORKING_DIR+"PAGE"+FOLDER_NUMBER+".pptx"),"ppt/slides/slide1.xml");

			String inString = new String(newZip);

			inString = inString.replaceAll("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");
			
			inString = 
					"<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">"
	+"<xsl:output method=\"xml\" encoding=\"UTF-8\" indent=\"yes\" standalone=\"yes\"/>"
	+"<xsl:template match=\"/\">"

			+inString
			+"</xsl:template>"
+"</xsl:stylesheet>";
			
			FileOutputStream fos2 = new FileOutputStream(WORKING_DIR+"tmp/"+System.currentTimeMillis()+".slide1.xslt");
			fos2.write(inString.getBytes());

			fos2.flush();
			fos2.close();
			
			System.out.println("XSTL Created Successfully!");

		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	static byte[] get(String name) throws IOException{
		InputStream instream = new FileInputStream(name);
		byte [] arr = new byte[instream.available()];
		instream.read(arr, 0, instream.available());
		return arr;
	}
}
