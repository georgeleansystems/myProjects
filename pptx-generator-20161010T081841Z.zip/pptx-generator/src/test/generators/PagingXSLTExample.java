package test.generators;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import za.co.absa.document.generators.ZipFileBuilder;


public class PagingXSLTExample {
	public static void main(String[] args) {

		try {
			
			String WORKING_DIR = "xslt_example/";
			Reader reader = new InputStreamReader(new FileInputStream(WORKING_DIR+"parameters.xml"));		
			StringWriter writer = new StringWriter();
			TransformerFactory tFactory = TransformerFactory.newInstance();
			StreamSource xslStream = new StreamSource(new FileInputStream((WORKING_DIR+"transformation.xslt")));
			Transformer transformer = tFactory.newTransformer(xslStream);
			transformer.transform(new javax.xml.transform.stream.StreamSource(reader),
					new javax.xml.transform.stream.StreamResult(writer));
			String result = writer.toString();
			

			byte [] newZip = ZipFileBuilder.add(get(WORKING_DIR+"fixed_without_xml.pptx"), result.getBytes(),"ppt/slides/slide1.xml");			
			FileOutputStream fos = new FileOutputStream(WORKING_DIR+"tmp/"+System.currentTimeMillis()+".generated.pptx");
			fos.write(newZip);

			FileOutputStream fos2 = new FileOutputStream(WORKING_DIR+"tmp/"+System.currentTimeMillis()+".generated.slide1.xml");
			fos2.write(result.getBytes());

			fos2.flush();
			fos2.close();
			
			fos.flush();
			fos.close();

			System.out.println("XML Created Successfully!");

		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	static byte[] get(String name) throws IOException{
		InputStream instream = new FileInputStream(name);
		byte [] arr = new byte[instream.available()];
		instream.read(arr, 0, instream.available());
		return arr;
	}

}
