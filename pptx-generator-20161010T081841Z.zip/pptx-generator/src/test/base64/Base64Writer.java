package test.base64;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import com.itextpdf.text.pdf.codec.Base64;

import za.co.absa.document.generators.ZipFileBuilder;


public class Base64Writer {
	public static void main(String[] args) {

		try {
			

			byte [] newZip = get("ARGO_COMPLIANCE_REPORT_TEMPLATE_XSLT_v.1.3.0.pptx");			
			FileOutputStream fos = new FileOutputStream("tmp/"+System.currentTimeMillis()+".Base64_Template.txt");
			fos.write(Base64.encodeBytes(newZip).getBytes());

			fos.flush();
			fos.close();

			System.out.println("XML Created Successfully!");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	static byte[] get(String name) throws IOException{
		InputStream instream = new FileInputStream(name);
		byte [] arr = new byte[instream.available()];
		instream.read(arr, 0, instream.available());
		return arr;
	}

}
