import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import za.co.absa.document.Mime;
import za.co.absa.document.merger.DocumentMergerFactory;
import za.co.absa.document.splitter.DocumentSplitterFactory;
import za.co.absa.document.splitter.PagesRegexHelper;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.itextpdf.text.pdf.codec.Base64;


public class DocumentSplitter_Flow_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		MbMessage outMessage = new MbMessage();
		outAssembly = new MbMessageAssembly(inAssembly,	outMessage);
		copyMessageHeaders(inMessage, outMessage);

		try{
			MbElement inRootElement = inMessage.getRootElement();
			
			/*We expect 
			
			<DOCUMENTS>
				<SPLITS>
					<SPLIT>1</SPLIT>
					<SPLIT>1-4</SPLIT>
					<SPLIT>1,4,5</SPLIT>
					<SPLIT>1-4,3-9</SPLIT>
				</SPLITS>
				<DOCUMENT>Base64String</DOCUMENT>
			</DOCUMENTS>
			
			--We return 
			<SPLIT_DOCUMENT>Base64String</SPLIT_DOCUMENT>
			*/			
			
			List<MbElement>  inDocumentElements =  (List) inRootElement.getLastChild().evaluateXPath("./DOCUMENTS/DOCUMENT");
			
			
			List<MbElement>  splitElements =  (List) inRootElement.getLastChild().evaluateXPath("./DOCUMENTS/SPLITS/SPLIT");
			
			//
			String [] splits = new String[splitElements.size()];

			int j = 0;
			for(MbElement element:inDocumentElements){
				splits[j++] = (String)element.getValue();
			}

			//
			byte[] documentBase64 = Base64.decode((String)inDocumentElements.get(0).getValue());
						
			byte[] mergedDocument = DocumentSplitterFactory.getInstance().getSplitter(Mime.PDF.getMime()).extractPages(documentBase64,PagesRegexHelper.regexToPages(splits));
			
			MbElement outRoot = outMessage.getRootElement();
			MbElement outBody = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);

			outBody.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "SPLIT_DOCUMENT", Base64.encodeBytes(mergedDocument));

			out.propagate(outAssembly);
			
		}
		catch(Exception e){
		    StringWriter sw = new StringWriter();
		    PrintWriter pw = new PrintWriter(sw);
		    e.printStackTrace(pw);

			throw new MbUserException(this, e.getMessage(), sw.toString(), "", e.getClass()+ " "+ e.toString(),null);
		}

	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
																	// the last
																	// child
																	// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}
	

}
