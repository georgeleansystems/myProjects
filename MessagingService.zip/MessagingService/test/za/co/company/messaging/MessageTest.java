package za.co.company.messaging;

import javax.mail.Session;

import org.junit.Test;

import za.co.company.messaging.EmailMessageSender;
import za.co.company.messaging.MailSessionFactory;
import za.co.company.messaging.Message;


public class MessageTest {
	
	@Test
	public void testGetInstance() throws Exception{
		
		Message message = new Message();
		
		message
		.to("sello.tseka@absa.co.za")
		.from("sello.tseka@gmail.com")
		.subject("Hello")
		.body("Hello");

		MailSessionFactory instance = MailSessionFactory.getInstance();
		org.junit.Assert.assertNotNull(instance);
		
		Session session = instance.getSession();

		org.junit.Assert.assertNotNull(session);
		
		EmailMessageSender messageSender = new EmailMessageSender(session);
		
		messageSender.sendMessage(message);

	}

}
