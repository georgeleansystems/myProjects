package za.co.company.messaging;

import java.io.Serializable;

public class MessagingAccount implements Serializable{
	private String username;
	private String secrete;
	
	
	
}
