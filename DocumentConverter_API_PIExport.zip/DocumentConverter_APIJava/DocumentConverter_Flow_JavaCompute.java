import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import za.co.absa.document.Mime;
import za.co.absa.document.converters.DocumentConverterFactory;
import za.co.absa.document.merger.DocumentMergerFactory;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.ibm.xml.crypto.util.Base64;


public class DocumentConverter_Flow_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		MbMessage outMessage = new MbMessage();
		outAssembly = new MbMessageAssembly(inAssembly,	outMessage);
		copyMessageHeaders(inMessage, outMessage);

		try{
			MbElement inRootElement = inMessage.getRootElement();
			
			/*
			   We expect 
			   <DOCUMENTS>
			     <DOCUMENT>Base64String</TEMPLATE>
	     		 <FROM_MIME>mime</FROM_MIME>
	     		 <TO_MIME>mime</TO_MIME>
			  </DOCUMENTS>
			 */
			
			List<MbElement> templateElements =  (List) inRootElement.getLastChild().evaluateXPath("./DOCUMENTS/DOCUMENT");
			List<MbElement> paramsElements =  (List) inRootElement.getLastChild().evaluateXPath("./DOCUMENTS/FROM_MIME");
			List<MbElement> mimeElements =  (List) inRootElement.getLastChild().evaluateXPath("./DOCUMENTS/TO_MIME");
			
			byte[]  template = Base64.decode((String)templateElements.get(0).getValue());
			String  from_mime = (String)paramsElements.get(0).getValue();
			String  to_mime = (String)mimeElements.get(0).getValue();
			
						
			byte[] mergedDocument = DocumentConverterFactory.getInstance()
					.getConverter(from_mime,to_mime)
					.convert(template, from_mime, to_mime);
			
			MbElement outRoot = outMessage.getRootElement();
			MbElement outBody = outRoot.createElementAsLastChild(MbXMLNSC.PARSER_NAME);

			outBody.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "DOCUMENT", Base64.encode(mergedDocument));

			out.propagate(outAssembly);
			
		}
		catch(Exception e){
		    StringWriter sw = new StringWriter();
		    PrintWriter pw = new PrintWriter(sw);
		    e.printStackTrace(pw);

			throw new MbUserException(this, e.getMessage(), sw.toString(), "", e.getClass()+ " "+ e.toString(),null);
		}	
	}
	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
																	// the last
																	// child
																	// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
